Data descriptions and sources are listed in the descriptions.pdf. This PDF is from the R package, openintro, as is all of the data listed here. Many of the data sets have been collected by other folks and then republished here.

Visit us at openintro.org for other free materials!