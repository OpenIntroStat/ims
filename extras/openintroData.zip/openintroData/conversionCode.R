#=====> Navigate to folder <=====#
# setwd("c://folder/of/interest")

#=====> Load package and write files <=====#
library(openintro)

data(ballBearing)
write.table(ballBearing, "ballBearing.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(credits)
write.table(credits, "credits.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(census)
write.table(census, "census.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(gradesTV)
write.table(gradesTV, "gradesTV.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(heartTr)
write.table(heartTr, "heartTr.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(ipod)
write.table(ipod, "ipod.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(mammals)
write.table(mammals, "mammals.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(marathon)
write.table(marathon, "marathon.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(marioKart)
write.table(marioKart, "marioKart.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(possum)
write.table(possum, "possum.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(run10)
write.table(run10, "run10.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(satGPA)
write.table(satGPA, "satGPA.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(smoking)
write.table(smoking, "smoking.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(textbooks)
write.table(textbooks, "textbooks.txt", quote=FALSE, sep="\t", row.names=FALSE)

data(tips)
write.table(tips, "tips.txt", quote=FALSE, sep="\t", row.names=FALSE)

